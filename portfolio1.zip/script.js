// Simple light/dark mode toggle (optional)
document.addEventListener('DOMContentLoaded', () => {
    const body = document.body;
    const toggle = document.createElement('button');
    toggle.textContent = 'Toggle Dark Mode';
    toggle.onclick = () => {
        body.classList.toggle('dark-mode');
    };
    document.body.prepend(toggle);
});
